package Command.GraphicsEditor;

public interface Command {
    void execute();
    void undo();
}
