package Command.Light_Fan;

class Fan {
    void on() {
        System.out.println("Fan ON");
    }
}