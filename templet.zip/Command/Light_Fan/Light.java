package Command.Light_Fan;

class Light {
    void on() {
        System.out.println("Light ON");
    }
}


