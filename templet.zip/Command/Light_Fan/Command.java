package Command.Light_Fan;
interface Command {
    void execute();
}
