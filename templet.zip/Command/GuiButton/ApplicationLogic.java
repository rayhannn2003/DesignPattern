package Command.GuiButton;

class ApplicationLogic {

    public void save() {
        System.out.println("Saving file...");
    }

    public void print() {
        System.out.println("Printing document...");
    }

    public void exit() {
        System.out.println("Exiting application...");
    }
}
