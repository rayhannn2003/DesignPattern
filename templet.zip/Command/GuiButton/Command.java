package Command.GuiButton;

interface Command {
    void execute();
}
