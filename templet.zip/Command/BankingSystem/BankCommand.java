package Command.BankingSystem;

interface BankCommand {
    void execute();
    void undo();
}

