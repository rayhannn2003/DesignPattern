package Command.TextEditor;

public interface Command {
    void execute();
    void undo();
}
