package Mediator.AirportCheckIn;

public interface CheckInMediator {
    void checkInPassenger(String passengerName, Passenger passenger);
}
