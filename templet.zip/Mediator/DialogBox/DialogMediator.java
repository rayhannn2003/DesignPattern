package Mediator.DialogBox;

interface DialogMediator {
    void notify(Component sender, String event);
}
