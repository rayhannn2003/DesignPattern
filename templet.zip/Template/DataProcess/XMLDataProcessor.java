package Template.DataProcess;

class XMLDataProcessor extends DataProcessor {

    @Override
    protected void processData() {
        System.out.println("Processing XML data");
    }
}
