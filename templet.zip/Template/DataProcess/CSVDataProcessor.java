package Template.DataProcess;

class CSVDataProcessor extends DataProcessor {

    @Override
    protected void processData() {
        System.out.println("Processing CSV data");
    }
}

