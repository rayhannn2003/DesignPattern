import java.util.Objects;

/**
 * Mediator for all cross-object registration operations.
 *
 * Design goals (Issue 1):
 * - UI talks to one coordinator.
 * - Student no longer calls Course operations directly (except via compatibility wrappers).
 * - Course no longer mutates Student's internal lists.
 * - Course remains the source of truth for roster/waitlist.
 */
public class RegistrationMediator {
    private final RegistrarSystem registrar;

    public RegistrationMediator(RegistrarSystem registrar) {
        this.registrar = Objects.requireNonNull(registrar);
    }

    public RegistrarSystem getRegistrar() {
        return registrar;
    }

    // --- Student-facing flows ---

    /**
     * Enroll a student into a course.
     * Keeps existing print behavior by delegating to Course for decisions/messages.
     */
    public boolean enroll(Student s, Course c) {
        if (s == null || c == null) return false;

        if (!c.isVisibleToStudents()) {
            System.out.println("Course " + c.code + " is not available for student enrollment.");
            return false;
        }
        if (s.isEnrolledIn(c)) {
            System.out.println(s.name + " is already enrolled in " + c.code);
            return false;
        }

        // Delegate the rule decision to Course.
        boolean enrolled = c.tryEnroll(s);
        // IMPORTANT: Course.tryEnroll must no longer mutate Student lists after refactor.
        if (enrolled) {
            s.addEnrolledCourseDirect(c);
        }
        return enrolled;
    }

    public boolean waitlist(Student s, Course c) {
        if (s == null || c == null) return false;

        if (!c.isVisibleToStudents()) {
            System.out.println("Course " + c.code + " is not available.");
            return false;
        }
        if (s.isWaitlistedFor(c)) {
            System.out.println(s.name + " is already waitlisted for " + c.code);
            return false;
        }
        if (s.isEnrolledIn(c)) {
            System.out.println(s.name + " is already enrolled in " + c.code + "; cannot waitlist.");
            return false;
        }

        boolean waitlisted = c.addToWaitlist(s);
        // IMPORTANT: Course.addToWaitlist must no longer mutate Student lists after refactor.
        if (waitlisted) {
            s.addWaitlistCourseDirect(c);
        }
        return waitlisted;
    }

    /**
     * Drop student from course or remove from waitlist.
     * Delegates to Course for decisions/messages while mediator updates Student lists.
     */
    public boolean drop(Student s, Course c) {
        if (s == null || c == null) return false;

        // We need Course to perform roster/waitlist changes & print messages.
        // Course.dropStudent must no longer mutate Student lists after refactor.
        DropResult result = c.dropStudentViaMediator(s);

        // Apply Student-side updates.
        if (result.droppedFromEnrolled || result.removedFromWaitlist) {
            s.removeCourseDirect(c);
        }
        if (result.promotedStudent != null) {
            Student promoted = result.promotedStudent;
            // promoted is now enrolled in the course
            promoted.addEnrolledCourseDirect(c);
        }

        return result.changed;
    }

    // --- Admin flows (pass-through for now; still coordinated entrypoint for UI) ---

    public void setCourseStatusInteractive(Course course, CourseStatus newStatus, java.util.Scanner scanner) {
        if (course == null) return;

        // If cancelling, mediator must coordinate Student schedule cleanup.
        if (newStatus == CourseStatus.CANCELLED && course.status != CourseStatus.CANCELLED) {
            java.util.List<Student> affected = new java.util.ArrayList<>();
            affected.addAll(course.getEnrolledStudentsSnapshot());
            affected.addAll(course.getWaitlistedStudentsSnapshot());

            course.setStatusAdminInteractive(newStatus, scanner);

            for (Student s : affected) {
                if (s != null) {
                    s.removeCourseDirect(course);
                }
            }
            return;
        }

        course.setStatusAdminInteractive(newStatus, scanner);
    }

    public void setCourseCapacity(Course course, int newCapacity) {
        if (course == null) return;
        course.setCapacity(newCapacity);
    }

    public void setCourseStatus(Course course, CourseStatus newStatus) {
        if (course == null) return;

        if (newStatus == CourseStatus.CANCELLED && course.status != CourseStatus.CANCELLED) {
            java.util.List<Student> affected = new java.util.ArrayList<>();
            affected.addAll(course.getEnrolledStudentsSnapshot());
            affected.addAll(course.getWaitlistedStudentsSnapshot());

            course.setStatusAdminFromMediator(newStatus);

            for (Student s : affected) {
                if (s != null) {
                    s.removeCourseDirect(course);
                }
            }
            return;
        }

        course.setStatusAdmin(newStatus);
    }

    /**
     * Helper value object so Course can report what happened without touching Student.
     */
    public static class DropResult {
        public final boolean changed;
        public final boolean droppedFromEnrolled;
        public final boolean removedFromWaitlist;
        public final Student promotedStudent;

        public DropResult(boolean changed, boolean droppedFromEnrolled, boolean removedFromWaitlist, Student promotedStudent) {
            this.changed = changed;
            this.droppedFromEnrolled = droppedFromEnrolled;
            this.removedFromWaitlist = removedFromWaitlist;
            this.promotedStudent = promotedStudent;
        }
    }
}
