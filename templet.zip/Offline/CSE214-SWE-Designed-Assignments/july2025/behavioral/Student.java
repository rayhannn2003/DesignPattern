import java.util.ArrayList;
import java.util.List;

public class Student {
    public final String id;
    public final String name;
    private final List<Course> enrolledCourses = new ArrayList<>();
    private final List<Course> waitlistedCourses = new ArrayList<>();

    public Student(String id, String name) {
        this.id = id;
        this.name = name;
    }

    // This is set by RegistrarSystem when the student is registered.
    // TestScenarios can remain unchanged because it still constructs Students directly.
    private RegistrarSystem registrar;

    void setRegistrarSystem(RegistrarSystem registrar) {
        this.registrar = registrar;
    }

    public void enrollIn(Course c) {
        if (c == null) return;
        if (registrar == null) {
            // Fallback to old behavior if student wasn't added to a RegistrarSystem.
            if (!c.isVisibleToStudents()) {
                System.out.println("Course " + c.code + " is not available for student enrollment.");
                return;
            }
            if (enrolledCourses.contains(c)) {
                System.out.println(name + " is already enrolled in " + c.code);
                return;
            }
            c.tryEnroll(this);
            return;
        }
        registrar.getMediator().enroll(this, c);
    }

    public void waitlistFor(Course c) {
        if (c == null) return;
        if (registrar == null) {
            // Fallback to old behavior if student wasn't added to a RegistrarSystem.
            if (!c.isVisibleToStudents()) {
                System.out.println("Course " + c.code + " is not available.");
                return;
            }
            if (waitlistedCourses.contains(c)) {
                System.out.println(name + " is already waitlisted for " + c.code);
                return;
            }
            if (enrolledCourses.contains(c)) {
                System.out.println(name + " is already enrolled in " + c.code + "; cannot waitlist.");
                return;
            }
            c.addToWaitlist(this);
            return;
        }
        registrar.getMediator().waitlist(this, c);
    }

    public void dropCourse(Course c) {
        if (c == null) return;
        if (registrar == null) {
            c.dropStudent(this);
            return;
        }
        registrar.getMediator().drop(this, c);
    }

    // Query helpers (used by mediator / UI)
    public boolean isEnrolledIn(Course c) {
        return c != null && enrolledCourses.contains(c);
    }

    public boolean isWaitlistedFor(Course c) {
        return c != null && waitlistedCourses.contains(c);
    }

    // For Course to call directly:
    public void addEnrolledCourseDirect(Course c) {
        if (!enrolledCourses.contains(c)) {
            enrolledCourses.add(c);
        }
        waitlistedCourses.remove(c);
    }

    public void addWaitlistCourseDirect(Course c) {
        if (!waitlistedCourses.contains(c)) {
            waitlistedCourses.add(c);
        }
    }

    public void removeCourseDirect(Course c) {
        enrolledCourses.remove(c);
        waitlistedCourses.remove(c);
    }

    public void printSchedule() {
        System.out.println("Schedule for " + name + " (" + id + "):");
        System.out.println("  Enrolled:");
        if (enrolledCourses.isEmpty()) {
            System.out.println("    [none]");
        } else {
            for (Course c : enrolledCourses) {
                System.out.println("    " + c.code + " - " + c.title + " (" + c.status + ")");
            }
        }
        System.out.println("  Waitlisted:");
        if (waitlistedCourses.isEmpty()) {
            System.out.println("    [none]");
        } else {
            for (Course c : waitlistedCourses) {
                System.out.println("    " + c.code + " - " + c.title + " (" + c.status + ")");
            }
        }
    }
}
