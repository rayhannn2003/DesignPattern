import java.util.Scanner;

public class ClosedState implements CourseState {
    @Override
    public CourseStatus getStatus() {
        return CourseStatus.CLOSED;
    }

    @Override
    public boolean tryEnroll(Course course, Student student) {
        System.out.println("Cannot enroll; course is CLOSED: " + course.code);
        return false;
    }

    @Override
    public boolean addToWaitlist(Course course, Student student) {
        System.out.println("Cannot waitlist; course not accepting waitlist: " + course.code);
        return false;
    }

    @Override
    public RegistrationMediator.DropResult dropStudentViaMediator(Course course, Student student) {
        // CLOSED still allows dropping/removing waitlist in the current design.
        if (course.getEnrolledInternal().contains(student)) {
            course.getEnrolledInternal().remove(student);
            System.out.println("Dropped from enrolled: " + student.name + " from " + course.code);
            return new RegistrationMediator.DropResult(true, true, false, null);
        }
        if (course.getWaitlistInternal().contains(student)) {
            course.getWaitlistInternal().remove(student);
            System.out.println("Removed from waitlist: " + student.name + " for " + course.code);
            return new RegistrationMediator.DropResult(true, false, true, null);
        }
        System.out.println(student.name + " is neither enrolled nor waitlisted for " + course.code);
        return new RegistrationMediator.DropResult(false, false, false, null);
    }

    @Override
    public void setCapacity(Course course, int newCapacity) {
        if (newCapacity < 0) newCapacity = 0;
        System.out.println("Setting capacity of " + course.code + " to " + newCapacity);
        course.setCapacityInternal(newCapacity);
        if (course.status == CourseStatus.CANCELLED) {
            System.out.println("Course is CANCELLED; capacity change has no effect.");
        }
        // CLOSED stays CLOSED
    }

    @Override
    public void setStatusAdmin(Course course, CourseStatus newStatus) {
        if (newStatus == null) return;
        if (newStatus == course.status) {
            System.out.println("No change: " + course.code + " already " + course.status);
            return;
        }

        if (newStatus == CourseStatus.OPEN) {
            course.setState(new OpenState());
            System.out.println(course.code + " transitioned CLOSED -> OPEN");
        } else if (newStatus == CourseStatus.DRAFT) {
            course.setState(new DraftState());
            System.out.println(course.code + " transitioned CLOSED -> DRAFT");
        } else if (newStatus == CourseStatus.CANCELLED) {
            course.cancelCourseInternal();
            course.setState(new CancelledState());
        } else {
            System.out.println("Invalid transition from CLOSED to " + newStatus);
        }
    }

    @Override
    public void setStatusAdminInteractive(Course course, CourseStatus newStatus, Scanner scanner) {
        setStatusAdmin(course, newStatus);
    }
}
