import java.util.Scanner;

public class OpenState implements CourseState {
    @Override
    public CourseStatus getStatus() {
        return CourseStatus.OPEN;
    }

    @Override
    public boolean tryEnroll(Course course, Student student) {
        if (course.getEnrolledInternal().contains(student)) {
            System.out.println("Already enrolled: " + student.name + " in " + course.code);
            return true;
        }

        if (course.getEnrolledInternal().size() < course.getCapacityInternal()) {
            course.getEnrolledInternal().add(student);
            System.out.println("Enrolled: " + student.name + " in " + course.code);
            if (course.getEnrolledInternal().size() >= course.getCapacityInternal()) {
                course.setState(new FullState());
                System.out.println(course.code + " is now FULL.");
            }
            return true;
        }

        // Capacity reached while OPEN
        course.setState(new FullState());
        System.out.println(course.code + " reached capacity; status set to FULL. Try waitlisting.");
        return false;
    }

    @Override
    public boolean addToWaitlist(Course course, Student student) {
        System.out.println("Course is OPEN; try enrolling instead: " + course.code);
        return false;
    }

    @Override
    public RegistrationMediator.DropResult dropStudentViaMediator(Course course, Student student) {
        // OPEN uses same drop logic as FULL/CLOSED regarding enrolled/waitlist removal,
        // but without special status-triggered restrictions.
        if (course.getEnrolledInternal().contains(student)) {
            course.getEnrolledInternal().remove(student);
            System.out.println("Dropped from enrolled: " + student.name + " from " + course.code);

            boolean promoted = false;
            Student promotedStudent = null;
            if (course.getEnrolledInternal().size() < course.getCapacityInternal() && !course.getWaitlistInternal().isEmpty()) {
                promotedStudent = course.getWaitlistInternal().poll();
                if (promotedStudent != null) {
                    course.getEnrolledInternal().add(promotedStudent);
                    System.out.println("Promoted from waitlist: " + promotedStudent.name + " into " + course.code);
                    promoted = true;
                }
            }

            // OPEN stays OPEN unless it reaches capacity
            if (course.getEnrolledInternal().size() >= course.getCapacityInternal()) {
                course.setState(new FullState());
            }

            return new RegistrationMediator.DropResult(true, true, false, promoted ? promotedStudent : null);
        }

        if (course.getWaitlistInternal().contains(student)) {
            course.getWaitlistInternal().remove(student);
            System.out.println("Removed from waitlist: " + student.name + " for " + course.code);
            return new RegistrationMediator.DropResult(true, false, true, null);
        }

        System.out.println(student.name + " is neither enrolled nor waitlisted for " + course.code);
        return new RegistrationMediator.DropResult(false, false, false, null);
    }

    @Override
    public void setCapacity(Course course, int newCapacity) {
        if (newCapacity < 0) newCapacity = 0;
        System.out.println("Setting capacity of " + course.code + " to " + newCapacity);
        course.setCapacityInternal(newCapacity);

        if (course.getEnrolledInternal().size() < course.getCapacityInternal()) {
            course.setState(new OpenState());
            System.out.println(course.code + " status changed to OPEN (capacity allows enrollment).");
        } else if (course.getEnrolledInternal().size() == course.getCapacityInternal()) {
            course.setState(new FullState());
            System.out.println(course.code + " status changed to FULL (at capacity).");
        } else {
            course.setState(new FullState());
            System.out.println(course.code + " over capacity; remains FULL.");
        }
    }

    @Override
    public void setStatusAdmin(Course course, CourseStatus newStatus) {
        if (newStatus == null) return;
        if (newStatus == course.status) {
            System.out.println("No change: " + course.code + " already " + course.status);
            return;
        }

        if (newStatus == CourseStatus.CLOSED) {
            course.setState(new ClosedState());
            System.out.println(course.code + " transitioned OPEN -> CLOSED");
        } else if (newStatus == CourseStatus.DRAFT) {
            course.setState(new DraftState());
            System.out.println(course.code + " transitioned OPEN -> DRAFT");
        } else if (newStatus == CourseStatus.CANCELLED) {
            course.cancelCourseInternal();
            course.setState(new CancelledState());
        } else {
            System.out.println("Invalid transition from OPEN to " + newStatus);
        }
    }

    @Override
    public void setStatusAdminInteractive(Course course, CourseStatus newStatus, Scanner scanner) {
        setStatusAdmin(course, newStatus);
    }
}
