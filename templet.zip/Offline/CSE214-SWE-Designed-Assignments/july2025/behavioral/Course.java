import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Course {
    public final String code;
    public final String title;
    private int capacity;
    public CourseStatus status;
    private CourseState state;
    private final List<Student> enrolled = new ArrayList<>();
    private final LinkedList<Student> waitlist = new LinkedList<>();

    // Optional: set by RegistrarSystem when the course is registered.
    private RegistrarSystem registrar;

    // Prevents infinite recursion when a mediator-triggered cancellation calls back into Course.
    private boolean cancellationInProgress = false;

    public Course(String code, String title, int capacity, CourseStatus status) {
        this.code = code;
        this.title = title;
        this.capacity = Math.max(0, capacity);
        this.status = status;
        this.state = CourseStates.fromStatus(status);
    }

    void setRegistrarSystem(RegistrarSystem registrar) {
        this.registrar = registrar;
    }

    void setState(CourseState newState) {
        if (newState == null) return;
        this.state = newState;
        this.status = newState.getStatus();
    }

    CourseState getState() {
        return state;
    }

    // Package-private helpers for state classes (keep Course as source of truth)
    int getCapacityInternal() { return capacity; }
    void setCapacityInternal(int newCapacity) { this.capacity = Math.max(0, newCapacity); }
    List<Student> getEnrolledInternal() { return enrolled; }
    LinkedList<Student> getWaitlistInternal() { return waitlist; }

    public boolean isVisibleToStudents() {
        return status != CourseStatus.DRAFT && status != CourseStatus.CANCELLED;
    }

    public boolean tryEnroll(Student s) {
        if (s == null) return false;
        return state.tryEnroll(this, s);
    }

    public boolean addToWaitlist(Student s) {
        if (s == null) return false;
        return state.addToWaitlist(this, s);
    }

    public boolean dropStudent(Student s) {
        // Historical API: keep behavior by delegating to mediator-friendly implementation,
        // but without returning promotion details to callers.
        return dropStudentViaMediator(s).changed;
    }

    /**
     * Mediator-friendly drop. Same prints/behavior as {@link #dropStudent(Student)} but does not mutate Student lists.
     * The mediator uses the returned result to update Student schedules consistently.
     */
    public RegistrationMediator.DropResult dropStudentViaMediator(Student s) {
        if (s == null) return new RegistrationMediator.DropResult(false, false, false, null);
        return state.dropStudentViaMediator(this, s);
    }

    public void setCapacity(int newCapacity) {
        state.setCapacity(this, newCapacity);
    }

    public void setStatusAdmin(CourseStatus newStatus) {
        // Route cancellation through mediator to clean student schedules.
        if (newStatus == CourseStatus.CANCELLED && registrar != null && !cancellationInProgress) {
            registrar.getMediator().setCourseStatus(this, newStatus);
            return;
        }
        state.setStatusAdmin(this, newStatus);
    }

    /**
     * Internal-only status change used by the mediator to avoid recursion.
     * This does NOT do any Student schedule cleanup; mediator coordinates that.
     */
    void setStatusAdminFromMediator(CourseStatus newStatus) {
        if (newStatus == CourseStatus.CANCELLED) {
            cancellationInProgress = true;
            try {
                state.setStatusAdmin(this, newStatus);
            } finally {
                cancellationInProgress = false;
            }
            return;
        }
        state.setStatusAdmin(this, newStatus);
    }

    // Interactive version for admin with Scanner (prompts for capacity increase)
    public void setStatusAdminInteractive(CourseStatus newStatus, Scanner scanner) {
        state.setStatusAdminInteractive(this, newStatus, scanner);
    }

    void cancelCourseInternal() {
        status = CourseStatus.CANCELLED;
        // clear enrolled and waitlist (mediator should coordinate Student schedule updates)
        enrolled.clear();
        waitlist.clear();
        System.out.println(code + " has been CANCELLED. All students dropped and waitlist cleared.");
    }

    void closeWithRandomWaitlistSelectionInternal(int targetCapacity) {
        status = CourseStatus.CLOSED;
        System.out.println(code + " transitioned FULL -> CLOSED");
        
        // If there are waitlisted students and space available, promote random students
        if (!waitlist.isEmpty()) {
            int availableSlots = targetCapacity - enrolled.size();
            if (availableSlots > 0) {
                Random random = new Random();
                List<Student> waitlistCopy = new ArrayList<>(waitlist);
                int promotionCount = Math.min(availableSlots, waitlistCopy.size());
                
                System.out.println("Randomly selecting " + promotionCount + " student(s) from waitlist:");
                for (int i = 0; i < promotionCount; i++) {
                    int randomIndex = random.nextInt(waitlistCopy.size());
                    Student promoted = waitlistCopy.remove(randomIndex);
                    waitlist.remove(promoted);
                    enrolled.add(promoted);
                    System.out.println("  Randomly selected: " + promoted.name + " for " + code);
                }
            }
        }
    }

    public void printRoster() {
        System.out.println("Roster for " + code + " - " + title + " (" + status + ", cap=" + capacity + "):");
        if (enrolled.isEmpty()) {
            System.out.println("  [no enrolled]");
        } else {
            for (Student s : enrolled) {
                System.out.println("  " + s.id + " - " + s.name);
            }
        }
    }

    public void printWaitlist() {
        System.out.println("Waitlist for " + code + ":");
        if (waitlist.isEmpty()) {
            System.out.println("  [no waitlisted]");
        } else {
            for (Student s : waitlist) {
                System.out.println("  " + s.id + " - " + s.name);
            }
        }
    }

    // Exposed getters for UI/reporting
    public int getCapacity() { return capacity; }
    public int getEnrolledCount() { return enrolled.size(); }
    public int getWaitlistCount() { return waitlist.size(); }

    // Snapshots for mediator coordination (avoid leaking internal collections)
    public List<Student> getEnrolledStudentsSnapshot() {
        return new ArrayList<>(enrolled);
    }

    public List<Student> getWaitlistedStudentsSnapshot() {
        return new ArrayList<>(waitlist);
    }
}
