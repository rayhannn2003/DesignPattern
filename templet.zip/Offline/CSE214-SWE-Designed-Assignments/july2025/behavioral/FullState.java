import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class FullState implements CourseState {
    @Override
    public CourseStatus getStatus() {
        return CourseStatus.FULL;
    }

    @Override
    public boolean tryEnroll(Course course, Student student) {
        System.out.println("Cannot enroll; course is FULL. You may waitlist: " + course.code);
        return false;
    }

    @Override
    public boolean addToWaitlist(Course course, Student student) {
        if (course.getEnrolledInternal().contains(student)) {
            System.out.println("Already enrolled; no need to waitlist: " + student.name + " for " + course.code);
            return false;
        }
        if (course.getWaitlistInternal().contains(student)) {
            System.out.println("Already waitlisted: " + student.name + " for " + course.code);
            return false;
        }
        course.getWaitlistInternal().add(student);
        System.out.println("Waitlisted: " + student.name + " for " + course.code);
        return true;
    }

    @Override
    public RegistrationMediator.DropResult dropStudentViaMediator(Course course, Student student) {
        if (course.getEnrolledInternal().contains(student)) {
            course.getEnrolledInternal().remove(student);
            System.out.println("Dropped from enrolled: " + student.name + " from " + course.code);

            Student promotedStudent = null;
            if (course.getEnrolledInternal().size() < course.getCapacityInternal()) {
                if (!course.getWaitlistInternal().isEmpty()) {
                    promotedStudent = course.getWaitlistInternal().poll();
                    if (promotedStudent != null) {
                        course.getEnrolledInternal().add(promotedStudent);
                        System.out.println("Promoted from waitlist: " + promotedStudent.name + " into " + course.code);
                    }
                }

                // FULL -> OPEN if still space.
                if (course.getEnrolledInternal().size() < course.getCapacityInternal()) {
                    course.setState(new OpenState());
                    System.out.println(course.code + " status changed to OPEN due to available capacity.");
                } else {
                    course.setState(new FullState());
                }
            }

            return new RegistrationMediator.DropResult(true, true, false, promotedStudent);
        }

        if (course.getWaitlistInternal().contains(student)) {
            course.getWaitlistInternal().remove(student);
            System.out.println("Removed from waitlist: " + student.name + " for " + course.code);
            return new RegistrationMediator.DropResult(true, false, true, null);
        }

        System.out.println(student.name + " is neither enrolled nor waitlisted for " + course.code);
        return new RegistrationMediator.DropResult(false, false, false, null);
    }

    @Override
    public void setCapacity(Course course, int newCapacity) {
        if (newCapacity < 0) newCapacity = 0;
        System.out.println("Setting capacity of " + course.code + " to " + newCapacity);
        course.setCapacityInternal(newCapacity);

        if (course.status == CourseStatus.CANCELLED) {
            System.out.println("Course is CANCELLED; capacity change has no effect.");
            return;
        }

        if (course.getEnrolledInternal().size() < course.getCapacityInternal()) {
            if (course.status != CourseStatus.DRAFT) {
                course.setState(new OpenState());
                System.out.println(course.code + " status changed to OPEN (capacity allows enrollment).");
            }
        } else if (course.getEnrolledInternal().size() == course.getCapacityInternal()) {
            course.setState(new FullState());
            System.out.println(course.code + " status changed to FULL (at capacity).");
        } else {
            course.setState(new FullState());
            System.out.println(course.code + " over capacity; remains FULL.");
        }
    }

    @Override
    public void setStatusAdmin(Course course, CourseStatus newStatus) {
        if (newStatus == null) return;
        if (newStatus == course.status) {
            System.out.println("No change: " + course.code + " already " + course.status);
            return;
        }

        if (newStatus == CourseStatus.CLOSED) {
            // Non-interactive: close without prompting
            course.closeWithRandomWaitlistSelectionInternal(course.getCapacityInternal());
            course.setState(new ClosedState());
        } else if (newStatus == CourseStatus.CANCELLED) {
            course.cancelCourseInternal();
            course.setState(new CancelledState());
        } else {
            System.out.println("Invalid transition from FULL to " + newStatus + " (FULL->OPEN is automatic on drop)");
        }
    }

    @Override
    public void setStatusAdminInteractive(Course course, CourseStatus newStatus, Scanner scanner) {
        if (newStatus == null) return;
        if (newStatus == course.status) {
            System.out.println("No change: " + course.code + " already " + course.status);
            return;
        }

        if (newStatus == CourseStatus.CLOSED) {
            if (!course.getWaitlistInternal().isEmpty()) {
                System.out.println(course.code + " has " + course.getWaitlistInternal().size() + " student(s) on waitlist.");
                System.out.print("Do you want to increase capacity before closing? (Enter new capacity, or 0 to not increase): ");
                try {
                    int newCapacity = Integer.parseInt(scanner.nextLine().trim());
                    if (newCapacity > 0) {
                        if (newCapacity > course.getCapacityInternal()) {
                            course.setCapacityInternal(newCapacity);
                            System.out.println("Capacity increased to " + newCapacity);
                            course.closeWithRandomWaitlistSelectionInternal(newCapacity);
                        } else {
                            System.out.println("New capacity must be greater than current capacity (" + course.getCapacityInternal() + "). No change.");
                            course.closeWithRandomWaitlistSelectionInternal(course.getCapacityInternal());
                        }
                    } else {
                        System.out.println("No capacity increase.");
                        course.closeWithRandomWaitlistSelectionInternal(course.getCapacityInternal());
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Closing without capacity increase.");
                    course.closeWithRandomWaitlistSelectionInternal(course.getCapacityInternal());
                }
            } else {
                course.closeWithRandomWaitlistSelectionInternal(course.getCapacityInternal());
            }
            course.setState(new ClosedState());
            return;
        }

        setStatusAdmin(course, newStatus);
    }
}
