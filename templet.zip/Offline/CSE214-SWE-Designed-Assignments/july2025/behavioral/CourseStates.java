/** Utility factory for mapping CourseStatus to CourseState instances. */
public final class CourseStates {
    private CourseStates() {}

    public static CourseState fromStatus(CourseStatus status) {
        if (status == null) return new DraftState();
        switch (status) {
            case DRAFT:
                return new DraftState();
            case OPEN:
                return new OpenState();
            case FULL:
                return new FullState();
            case CLOSED:
                return new ClosedState();
            case CANCELLED:
                return new CancelledState();
            default:
                return new DraftState();
        }
    }
}
