import java.util.Scanner;

public class CancelledState implements CourseState {
    @Override
    public CourseStatus getStatus() {
        return CourseStatus.CANCELLED;
    }

    @Override
    public boolean tryEnroll(Course course, Student student) {
        System.out.println("Cannot enroll; course is CANCELLED: " + course.code);
        return false;
    }

    @Override
    public boolean addToWaitlist(Course course, Student student) {
        System.out.println("Cannot waitlist; course not accepting waitlist: " + course.code);
        return false;
    }

    @Override
    public RegistrationMediator.DropResult dropStudentViaMediator(Course course, Student student) {
        // In CANCELLED state, rosters are already cleared.
        System.out.println(student.name + " is neither enrolled nor waitlisted for " + course.code);
        return new RegistrationMediator.DropResult(false, false, false, null);
    }

    @Override
    public void setCapacity(Course course, int newCapacity) {
        if (newCapacity < 0) newCapacity = 0;
        System.out.println("Setting capacity of " + course.code + " to " + newCapacity);
        course.setCapacityInternal(newCapacity);
        System.out.println("Course is CANCELLED; capacity change has no effect.");
    }

    @Override
    public void setStatusAdmin(Course course, CourseStatus newStatus) {
        if (newStatus == null) return;
        if (newStatus == course.status) {
            System.out.println("No change: " + course.code + " already " + course.status);
            return;
        }

        if (newStatus == CourseStatus.DRAFT) {
            course.setState(new DraftState());
            System.out.println(course.code + " transitioned CANCELLED -> DRAFT (reinstating course)");
        } else {
            System.out.println("Invalid: CANCELLED can only transition to DRAFT for " + course.code);
        }
    }

    @Override
    public void setStatusAdminInteractive(Course course, CourseStatus newStatus, Scanner scanner) {
        setStatusAdmin(course, newStatus);
    }
}
