import java.util.Scanner;

/**
 * State interface for Course behavior (Issue 2).
 *
 * Each concrete state encapsulates:
 * - what operations are allowed
 * - how CourseStatus transitions happen
 * - what gets printed
 */
public interface CourseState {
    CourseStatus getStatus();

    boolean tryEnroll(Course course, Student student);

    boolean addToWaitlist(Course course, Student student);

    /**
     * Drop student and (optionally) promote from waitlist.
     * Must not mutate Student schedule lists; mediator coordinates that.
     */
    RegistrationMediator.DropResult dropStudentViaMediator(Course course, Student student);

    void setCapacity(Course course, int newCapacity);

    void setStatusAdmin(Course course, CourseStatus newStatus);

    void setStatusAdminInteractive(Course course, CourseStatus newStatus, Scanner scanner);
}
