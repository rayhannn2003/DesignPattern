import java.util.Scanner;

public class DraftState implements CourseState {
    @Override
    public CourseStatus getStatus() {
        return CourseStatus.DRAFT;
    }

    @Override
    public boolean tryEnroll(Course course, Student student) {
        System.out.println("Cannot enroll; course is DRAFT (not visible): " + course.code);
        return false;
    }

    @Override
    public boolean addToWaitlist(Course course, Student student) {
        System.out.println("Cannot waitlist; course not accepting waitlist: " + course.code);
        return false;
    }

    @Override
    public RegistrationMediator.DropResult dropStudentViaMediator(Course course, Student student) {
        // Same message behavior as before
        System.out.println(student.name + " is neither enrolled nor waitlisted for " + course.code);
        return new RegistrationMediator.DropResult(false, false, false, null);
    }

    @Override
    public void setCapacity(Course course, int newCapacity) {
        if (newCapacity < 0) newCapacity = 0;
        System.out.println("Setting capacity of " + course.code + " to " + newCapacity);
        course.setCapacityInternal(newCapacity);
        // DRAFT remains DRAFT
    }

    @Override
    public void setStatusAdmin(Course course, CourseStatus newStatus) {
        if (newStatus == null) return;
        if (newStatus == course.status) {
            System.out.println("No change: " + course.code + " already " + course.status);
            return;
        }

        if (newStatus == CourseStatus.OPEN) {
            course.setState(new OpenState());
            System.out.println(course.code + " transitioned DRAFT -> OPEN");
        } else if (newStatus == CourseStatus.CLOSED) {
            course.setState(new ClosedState());
            System.out.println(course.code + " transitioned DRAFT -> CLOSED");
        } else if (newStatus == CourseStatus.CANCELLED) {
            course.cancelCourseInternal();
            course.setState(new CancelledState());
        } else {
            System.out.println("Invalid transition from DRAFT to " + newStatus);
        }
    }

    @Override
    public void setStatusAdminInteractive(Course course, CourseStatus newStatus, Scanner scanner) {
        // No special interactive behavior from DRAFT
        setStatusAdmin(course, newStatus);
    }
}
