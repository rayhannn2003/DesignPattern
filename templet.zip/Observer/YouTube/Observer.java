package Observer.YouTube;

public interface Observer {
    void update(String channelName, String videoTitle);
}
