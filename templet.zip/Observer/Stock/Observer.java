package Observer.Stock;
public interface Observer {
    void update(String stockName, double price);
}
