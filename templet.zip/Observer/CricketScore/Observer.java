package Observer.CricketScore;

public interface Observer {
    void update(int runs, int wickets, double overs);
}
