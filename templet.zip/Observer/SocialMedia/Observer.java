package Observer.SocialMedia;

public interface Observer {
    void update(String channelName, String content);
}
