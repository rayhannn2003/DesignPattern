package Observer.Temperature;

interface Observer {
    void update(float temperature);
}
