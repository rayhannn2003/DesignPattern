package Strategy.ImageFilter;

public interface FilterStrategy {
    void applyFilter(String imageName);
}
