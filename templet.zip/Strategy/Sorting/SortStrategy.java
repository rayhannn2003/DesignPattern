package Strategy.Sorting;
interface SortStrategy {
    void sort(int[] arr);
}

