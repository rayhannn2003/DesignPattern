package Strategy.Navigation;

public interface RouteStrategy {
    void calculateRoute(String start, String destination);
}
