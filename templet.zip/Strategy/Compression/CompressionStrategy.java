package Strategy.Compression;

public interface CompressionStrategy {
    void compress(String fileName);
}
