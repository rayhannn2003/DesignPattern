import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class FullState implements CourseState {
    
    @Override
    public boolean tryEnroll(Student student, Course course, CourseMediator mediator) {
        System.out.println("Cannot enroll; course is FULL. You may waitlist: " + course.code);
        return false;
    }
    
    @Override
    public boolean addToWaitlist(Student student, Course course, CourseMediator mediator) {
        if (course.isEnrolled(student)) {
            System.out.println("Already enrolled; no need to waitlist: " + student.name + " for " + course.code);
            return false;
        }
        if (course.isWaitlisted(student)) {
            System.out.println("Already waitlisted: " + student.name + " for " + course.code);
            return false;
        }
        
        course.addToWaitlistDirect(student);
        mediator.notifyWaitlistSuccess(student, course);
        return true;
    }
    
    @Override
    public void setCapacity(int newCapacity, Course course) {
        course.setCapacityDirect(newCapacity);
        System.out.println("Setting capacity of " + course.code + " to " + newCapacity);
        
        int enrolled = course.getEnrolledCount();
        if (enrolled < newCapacity) {
            course.setState(new OpenState());
            System.out.println(course.code + " status changed to OPEN (capacity allows enrollment).");
        } else if (enrolled == newCapacity) {
            System.out.println(course.code + " status changed to FULL (at capacity).");
        } else {
            System.out.println(course.code + " over capacity; remains FULL.");
        }
    }
    
    @Override
    public void transitionTo(CourseStatus newStatus, Course course, CourseMediator mediator) {
        if (newStatus == CourseStatus.CLOSED) {
            // Non-interactive version, close without prompting
            closeWithRandomWaitlistSelection(course, course.getCapacity());
        } else if (newStatus == CourseStatus.CANCELLED) {
            course.setState(new CancelledState());
            course.cancelCourseDirect(mediator);
        } else {
            System.out.println("Invalid transition from FULL to " + newStatus + " (FULL->OPEN is automatic on drop)");
        }
    }
    
    @Override
    public void transitionToInteractive(CourseStatus newStatus, Course course, CourseMediator mediator, Scanner scanner) {
        if (newStatus == CourseStatus.CLOSED) {
            // Interactive version, prompt for capacity increase
            if (course.hasWaitlist()) {
                System.out.println(course.code + " has " + course.getWaitlistCount() + " student(s) on waitlist.");
                System.out.print("Do you want to increase capacity before closing? (Enter new capacity, or 0 to not increase): ");
                try {
                    int newCapacity = Integer.parseInt(scanner.nextLine().trim());
                    if (newCapacity > 0) {
                        if (newCapacity > course.getCapacity()) {
                            course.setCapacityDirect(newCapacity);
                            System.out.println("Capacity increased to " + newCapacity);
                            closeWithRandomWaitlistSelection(course, newCapacity);
                        } else {
                            System.out.println("New capacity must be greater than current capacity (" + course.getCapacity() + "). No change.");
                            closeWithRandomWaitlistSelection(course, course.getCapacity());
                        }
                    } else {
                        System.out.println("No capacity increase.");
                        closeWithRandomWaitlistSelection(course, course.getCapacity());
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Closing without capacity increase.");
                    closeWithRandomWaitlistSelection(course, course.getCapacity());
                }
            } else {
                // No waitlist, just close
                closeWithRandomWaitlistSelection(course, course.getCapacity());
            }
        } else if (newStatus == CourseStatus.CANCELLED) {
            course.setState(new CancelledState());
            course.cancelCourseDirect(mediator);
        } else {
            System.out.println("Invalid transition from FULL to " + newStatus + " (FULL->OPEN is automatic on drop)");
        }
    }
    
    private void closeWithRandomWaitlistSelection(Course course, int targetCapacity) {
        course.setState(new ClosedState());
        System.out.println(course.code + " transitioned FULL -> CLOSED");
        
        // If there are waitlisted students and space available, promote random students
        if (course.hasWaitlist()) {
            int availableSlots = targetCapacity - course.getEnrolledCount();
            if (availableSlots > 0) {
                Random random = new Random();
                List<Student> waitlistCopy = new ArrayList<>(course.getWaitlistCopy());
                int promotionCount = Math.min(availableSlots, waitlistCopy.size());
                
                System.out.println("Randomly selecting " + promotionCount + " student(s) from waitlist:");
                for (int i = 0; i < promotionCount; i++) {
                    int randomIndex = random.nextInt(waitlistCopy.size());
                    Student promoted = waitlistCopy.remove(randomIndex);
                    course.removeFromWaitlistDirect(promoted);
                    course.addEnrolledDirect(promoted);
                    promoted.addEnrolledCourseDirect(course);
                    System.out.println("  Randomly selected: " + promoted.name + " for " + course.code);
                }
            }
        }
    }
    
    @Override
    public CourseStatus getStatus() {
        return CourseStatus.FULL;
    }
    
    @Override
    public boolean isVisibleToStudents() {
        return true;
    }
    
    @Override
    public void handleDrop(Course course, CourseMediator mediator) {
        // After drop in FULL state, promote from waitlist and potentially change to OPEN
        if (course.getEnrolledCount() < course.getCapacity()) {
            if (course.hasWaitlist()) {
                mediator.promoteFromWaitlist(course);
            }
            // Recalculate status, FULL -> OPEN if space
            if (course.getEnrolledCount() < course.getCapacity()) {
                course.setState(new OpenState());
                System.out.println(course.code + " status changed to OPEN due to available capacity.");
            }
        }
    }
}
