import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Course {
    public final String code;
    public final String title;
    private int capacity;
    private CourseState currentState;
    private final List<Student> enrolled = new ArrayList<>();
    private final LinkedList<Student> waitlist = new LinkedList<>();
    private CourseMediator mediator;

    public Course(String code, String title, int capacity, CourseStatus status) {
        this.code = code;
        this.title = title;
        this.capacity = Math.max(0, capacity);
        // Initialize state based on status
        this.currentState = createStateFromStatus(status);
        this.status = status; 
    }
    
    private CourseState createStateFromStatus(CourseStatus status) {
        switch (status) {
            case DRAFT: return new DraftState();
            case OPEN: return new OpenState();
            case FULL: return new FullState();
            case CLOSED: return new ClosedState();
            case CANCELLED: return new CancelledState();
            default: return new DraftState();
        }
    }

    public void setMediator(CourseMediator mediator) {
        this.mediator = mediator;
    }


    public CourseStatus status;
    
    private void updateStatusField() {
        this.status = currentState.getStatus();
    }

    public boolean isVisibleToStudents() {
        return currentState.isVisibleToStudents();
    }
    
    // State management
    public void setState(CourseState newState) {
        this.currentState = newState;
        updateStatusField(); 
    }
    
    public CourseState getState() {
        return currentState;
    }


    public boolean tryEnroll(Student s) {
        if (s == null || mediator == null) return false;
        return currentState.tryEnroll(s, this, mediator);
    }


    public boolean addToWaitlist(Student s) {
        if (s == null || mediator == null) return false;
        return currentState.addToWaitlist(s, this, mediator);
    }

    public boolean dropStudent(Student s) {
        if (s == null || mediator == null) return false;
        boolean changed = false;
        
        if (enrolled.contains(s)) {
            enrolled.remove(s);
            mediator.notifyStudentRemoved(s, this);
            System.out.println("Dropped from enrolled: " + s.name + " from " + code);
            changed = true;
            
            currentState.handleDrop(this, mediator);
            
        } else if (waitlist.contains(s)) {
            waitlist.remove(s);
            mediator.notifyStudentRemoved(s, this);
            System.out.println("Removed from waitlist: " + s.name + " for " + code);
            changed = true;
        } else {
            System.out.println(s.name + " is neither enrolled nor waitlisted for " + code);
        }
        return changed;
    }


    public void setCapacity(int newCapacity) {
        if (newCapacity < 0) newCapacity = 0;
        currentState.setCapacity(newCapacity, this);
    }


    public void setStatusAdmin(CourseStatus newStatus) {
        if (newStatus == null) return;
        if (newStatus == currentState.getStatus()) {
            System.out.println("No change: " + code + " already " + currentState.getStatus());
            return;
        }
        currentState.transitionTo(newStatus, this, mediator);
    }

    // this is interactive version for admin with Scanner
    public void setStatusAdminInteractive(CourseStatus newStatus, Scanner scanner) {
        if (newStatus == null) return;
        if (newStatus == currentState.getStatus()) {
            System.out.println("No change: " + code + " already " + currentState.getStatus());
            return;
        }
        currentState.transitionToInteractive(newStatus, this, mediator, scanner);
    }


    public void cancelCourseDirect(CourseMediator mediator) {
        if (mediator != null) {
            for (Student s : new ArrayList<>(enrolled)) {
                mediator.notifyStudentRemoved(s, this);
            }
            for (Student s : new ArrayList<>(waitlist)) {
                mediator.notifyStudentRemoved(s, this);
            }
        }
        enrolled.clear();
        waitlist.clear();
        System.out.println(code + " has been CANCELLED. All students dropped and waitlist cleared.");
    }

    // these are helpr methods for states tomodify internal data
    public void setCapacityDirect(int newCapacity) {
        this.capacity = newCapacity;
    }
    
    public boolean isEnrolled(Student student) {
        return enrolled.contains(student);
    }
    
    public boolean isWaitlisted(Student student) {
        return waitlist.contains(student);
    }
    
    public void addToWaitlistDirect(Student student) {
        if (!waitlist.contains(student)) {
            waitlist.add(student);
        }
    }
    
    public void removeFromWaitlistDirect(Student student) {
        waitlist.remove(student);
    }
    
    public boolean hasWaitlist() {
        return !waitlist.isEmpty();
    }
    
    public List<Student> getWaitlistCopy() {
        return new ArrayList<>(waitlist);
    }

    public void printRoster() {
        System.out.println("Roster for " + code + " - " + title + " (" + currentState.getStatus() + ", cap=" + capacity + "):");
        if (enrolled.isEmpty()) {
            System.out.println("  [no enrolled]");
        } else {
            for (Student s : enrolled) {
                System.out.println("  " + s.id + " - " + s.name);
            }
        }
    }

    public void printWaitlist() {
        System.out.println("Waitlist for " + code + ":");
        if (waitlist.isEmpty()) {
            System.out.println("  [no waitlisted]");
        } else {
            for (Student s : waitlist) {
                System.out.println("  " + s.id + " - " + s.name);
            }
        }
    }

    // these are getters for concole UI or reporting
    public int getCapacity() { return capacity; }
    public int getEnrolledCount() { return enrolled.size(); }
    public int getWaitlistCount() { return waitlist.size(); }
    

    public Student pollFromWaitlist() {
        return waitlist.poll();
    }
    
    public void addEnrolledDirect(Student s) {
        if (s != null && !enrolled.contains(s)) {
            enrolled.add(s);
        }
    }
    
    // No longer needed - state manages status transitions
    // this was needed only when i fixed issue 1
    public void setStatusDirect(CourseStatus newStatus) {
        this.status = newStatus;
    }
}
