import java.util.Scanner;

public class ClosedState implements CourseState {
    
    @Override
    public boolean tryEnroll(Student student, Course course, CourseMediator mediator) {
        System.out.println("Cannot enroll; course is CLOSED: " + course.code);
        return false;
    }
    
    @Override
    public boolean addToWaitlist(Student student, Course course, CourseMediator mediator) {
        System.out.println("Cannot waitlist; course not accepting waitlist: " + course.code);
        return false;
    }
    
    @Override
    public void setCapacity(int newCapacity, Course course) {
        course.setCapacityDirect(newCapacity);
        System.out.println("Setting capacity of " + course.code + " to " + newCapacity);
        
        int enrolled = course.getEnrolledCount();
        if (enrolled < newCapacity) {
            course.setState(new OpenState());
            System.out.println(course.code + " status changed to OPEN (capacity allows enrollment).");
        } else if (enrolled == newCapacity) {
            course.setState(new FullState());
            System.out.println(course.code + " status changed to FULL (at capacity).");
        } else {
            course.setState(new FullState());
            System.out.println(course.code + " over capacity; remains FULL.");
        }
    }
    
    @Override
    public void transitionTo(CourseStatus newStatus, Course course, CourseMediator mediator) {
        transitionToInteractive(newStatus, course, mediator, null);
    }
    
    @Override
    public void transitionToInteractive(CourseStatus newStatus, Course course, CourseMediator mediator, Scanner scanner) {
        switch (newStatus) {
            case OPEN:
                course.setState(new OpenState());
                System.out.println(course.code + " transitioned CLOSED -> OPEN");
                break;
            case DRAFT:
                course.setState(new DraftState());
                System.out.println(course.code + " transitioned CLOSED -> DRAFT");
                break;
            case CANCELLED:
                course.setState(new CancelledState());
                course.cancelCourseDirect(mediator);
                break;
            default:
                System.out.println("Invalid transition from CLOSED to " + newStatus);
        }
    }
    
    @Override
    public CourseStatus getStatus() {
        return CourseStatus.CLOSED;
    }
    
    @Override
    public boolean isVisibleToStudents() {
        return true;
    }
    
    @Override
    public void handleDrop(Course course, CourseMediator mediator) {
        // No special handling needed for CLOSED state after drop
    }
}
