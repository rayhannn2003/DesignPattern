import java.util.Scanner;

public interface CourseMediator {
    // Student
    void enrollStudent(Student student, Course course);
    void waitlistStudent(Student student, Course course);
    void dropStudent(Student student, Course course);
    
    // Course 
    void setCourseStatus(Course course, CourseStatus newStatus);
    void setCourseStatusInteractive(Course course, CourseStatus newStatus, Scanner scanner);
    void setCourseCapacity(Course course, int newCapacity);
    
    // these will be called by course
    void notifyEnrollmentSuccess(Student student, Course course);
    void notifyWaitlistSuccess(Student student, Course course);
    void notifyStudentRemoved(Student student, Course course);
    void promoteFromWaitlist(Course course);
    void handleAutomaticStateTransition(Course course);
}
