import java.util.HashMap;
import java.util.Map;
import java.util.Collection;
import java.util.Scanner;

public class RegistrarSystem implements CourseMediator {
    private final Map<String, Student> students = new HashMap<>();
    private final Map<String, Course> courses = new HashMap<>();

    public void addStudent(Student s) {
        if (s != null) {
            students.put(s.id, s);
            s.setMediator(this);
        }
    }

    public void addCourse(Course c) {
        if (c != null) {
            courses.put(c.code, c);
            c.setMediator(this);
        }
    }

    public Student getStudent(String id) {
        return students.get(id);
    }

    public Course getCourse(String code) {
        return courses.get(code);
    }

    public Collection<Student> getAllStudents() {
        return students.values();
    }

    public Collection<Course> getAllCourses() {
        return courses.values();
    }

    //  Mediator implementation
    
    @Override
    public void enrollStudent(Student student, Course course) {
        if (student == null || course == null) return;
        
        if (!course.isVisibleToStudents()) {
            System.out.println("Course " + course.code + " is not available for student enrollment.");
            return;
        }
        
        if (student.isEnrolledIn(course)) {
            System.out.println(student.name + " is already enrolled in " + course.code);
            return;
        }
        
        course.tryEnroll(student);
    }

    @Override
    public void waitlistStudent(Student student, Course course) {
        if (student == null || course == null) return;
        
        if (!course.isVisibleToStudents()) {
            System.out.println("Course " + course.code + " is not available.");
            return;
        }
        
        if (student.isWaitlistedFor(course)) {
            System.out.println(student.name + " is already waitlisted for " + course.code);
            return;
        }
        
        if (student.isEnrolledIn(course)) {
            System.out.println(student.name + " is already enrolled in " + course.code + "; cannot waitlist.");
            return;
        }
        
        course.addToWaitlist(student);
    }

    @Override
    public void dropStudent(Student student, Course course) {
        if (student == null || course == null) return;
        
        course.dropStudent(student);
    }

    @Override
    public void setCourseStatus(Course course, CourseStatus newStatus) {
        if (course == null || newStatus == null) return;
        course.setStatusAdmin(newStatus);
    }

    @Override
    public void setCourseStatusInteractive(Course course, CourseStatus newStatus, Scanner scanner) {
        if (course == null || newStatus == null) return;
        course.setStatusAdminInteractive(newStatus, scanner);
    }

    @Override
    public void setCourseCapacity(Course course, int newCapacity) {
        if (course == null) return;
        course.setCapacity(newCapacity);
    }

    // these will be called by course
    
    @Override
    public void notifyEnrollmentSuccess(Student student, Course course) {
     
        student.addEnrolledCourseDirect(course);
        System.out.println("Enrolled: " + student.name + " in " + course.code);
    }

    @Override
    public void notifyWaitlistSuccess(Student student, Course course) {
 
        student.addWaitlistCourseDirect(course);
        System.out.println("Waitlisted: " + student.name + " for " + course.code);
    }

    @Override
    public void notifyStudentRemoved(Student student, Course course) {

        student.removeCourseDirect(course);
    }

    @Override
    public void promoteFromWaitlist(Course course) {
        if (course == null) return;
        
        Student promoted = course.pollFromWaitlist();
        if (promoted != null) {

            course.addEnrolledDirect(promoted);
            

            promoted.addEnrolledCourseDirect(course);
            promoted.removeCourseDirect(course); // Remove from waitlist
            
            System.out.println("Promoted from waitlist: " + promoted.name + " into " + course.code);
        }
    }

    @Override
    public void handleAutomaticStateTransition(Course course) {
        if (course == null) return;
        
        //automatic OPEN - FULL transitions based on capacity
        int enrolled = course.getEnrolledCount();
        int capacity = course.getCapacity();
        CourseStatus currentStatus = course.status;
        
        if (currentStatus == CourseStatus.OPEN && enrolled >= capacity) {
            course.setStatusDirect(CourseStatus.FULL);
            System.out.println(course.code + " is now FULL.");
        } else if (currentStatus == CourseStatus.FULL && enrolled < capacity) {
            course.setStatusDirect(CourseStatus.OPEN);
            System.out.println(course.code + " status changed to OPEN due to available capacity.");
        }
    }
}
