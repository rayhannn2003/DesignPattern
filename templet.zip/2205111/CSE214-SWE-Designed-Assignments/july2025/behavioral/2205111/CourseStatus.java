public enum CourseStatus {
    DRAFT,
    OPEN,
    FULL,
    CLOSED,
    CANCELLED
}
