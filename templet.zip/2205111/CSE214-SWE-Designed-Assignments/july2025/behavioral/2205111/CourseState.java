import java.util.Scanner;

public interface CourseState {

    boolean tryEnroll(Student student, Course course, CourseMediator mediator);
    
    boolean addToWaitlist(Student student, Course course, CourseMediator mediator);

    void setCapacity(int newCapacity, Course course);
    
    //state transition via admin 
    void transitionTo(CourseStatus newStatus, Course course, CourseMediator mediator);
    
    //transition method for user trying
    void transitionToInteractive(CourseStatus newStatus, Course course, CourseMediator mediator, Scanner scanner);
    
    CourseStatus getStatus();
    
    boolean isVisibleToStudents();
    
    void handleDrop(Course course, CourseMediator mediator);
}
