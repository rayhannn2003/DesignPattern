import java.util.Scanner;

public class DraftState implements CourseState {
    
    @Override
    public boolean tryEnroll(Student student, Course course, CourseMediator mediator) {
        System.out.println("Cannot enroll; course is DRAFT (not visible): " + course.code);
        return false;
    }
    
    @Override
    public boolean addToWaitlist(Student student, Course course, CourseMediator mediator) {
        System.out.println("Cannot waitlist; course not accepting waitlist: " + course.code);
        return false;
    }
    
    @Override
    public void setCapacity(int newCapacity, Course course) {
        course.setCapacityDirect(newCapacity);
        System.out.println("Setting capacity of " + course.code + " to " + newCapacity);
        // DRAFT state doesn't change based on capacity
    }
    
    @Override
    public void transitionTo(CourseStatus newStatus, Course course, CourseMediator mediator) {
        transitionToInteractive(newStatus, course, mediator, null);
    }
    
    @Override
    public void transitionToInteractive(CourseStatus newStatus, Course course, CourseMediator mediator, Scanner scanner) {
        switch (newStatus) {
            case OPEN:
                course.setState(new OpenState());
                System.out.println(course.code + " transitioned DRAFT -> OPEN");
                break;
            case CLOSED:
                course.setState(new ClosedState());
                System.out.println(course.code + " transitioned DRAFT -> CLOSED");
                break;
            case CANCELLED:
                course.setState(new CancelledState());
                course.cancelCourseDirect(mediator);
                break;
            default:
                System.out.println("Invalid transition from DRAFT to " + newStatus);
        }
    }
    
    @Override
    public CourseStatus getStatus() {
        return CourseStatus.DRAFT;
    }
    
    @Override
    public boolean isVisibleToStudents() {
        return false;
    }
    
    @Override
    public void handleDrop(Course course, CourseMediator mediator) {
        // Nothing special needed for DRAFT state after drop
    }
}
