package State.LightThread;
public interface TrafficLightState {
    void handle(TrafficLight context);
}
