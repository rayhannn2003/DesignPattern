package State.LightState;

interface TrafficLightState {

    void changeLight(TrafficLight light);
}
